﻿using System;
using System.Linq;
using EDLib;
using EDLib.SQL;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Configuration;
using System.Reflection;
using System.Collections;
using MyCSharpLib;

namespace ETNBrokerData
{
    class Program
    {
        static string lastTDate = DateTime.Now.ToString("yyyyMMdd");
        //static string lastTDate = TradeDate.LastNTradeDate(2).ToString("yyyyMMdd");
        //static string lastTDate = "20190522";
        static List<string> LastTDateList = new List<string>();

        static void Main(string[] args)
        {
            LastTDateList.Add(lastTDate);

            //Console.WriteLine("ETNBasicDataUpdate Query Begins...");
            //ETNBroker.ETNBasicDataUpdater(LastTDateList);

            Console.WriteLine("ETNBroker Query Begins...");
            ETNBroker.ETNBrokerCalculator(LastTDateList);

            Console.WriteLine("ETNTradingBroker Query Begins...");
            ETNBroker.ETNTradingBrokerCalculator(LastTDateList);

            Console.WriteLine("ETNTradingBroker Insert FakeData Begins...");
            ETNBroker.ETNNonTradeInsert(LastTDateList);



            //ETNBroker.MailSender();

            Console.WriteLine("END------------------------------------\n");
            //Console.ReadLine();

        }
    }
    
    class ETNBroker
    {
        static DataTable etnBasicData;
        static DataTable etnBroker;
        static DataTable etfMML;
        static DataTable etfMM;
        static DataTable summary;
        static DataTable NonTradeETN;
        static DataTable TradeETN;

        static DataTable InitializeTables()
        {
            DataTable dt = new DataTable();
            //dt.Columns.Add("TDate", typeof(DateTime));
            dt.Columns.Add("TDate", typeof(string));
            dt.Columns.Add("IssuerID", typeof(string));
            dt.Columns.Add("IssuerName", typeof(string));
            dt.Columns.Add("ETNID", typeof(string));
            dt.Columns.Add("ETNName", typeof(string));
            dt.Columns.Add("BrokerID", typeof(string));
            dt.Columns.Add("BuyingLots", typeof(string));
            dt.Columns.Add("BuyingAmount", typeof(string));
            dt.Columns.Add("SellingLots", typeof(string));
            dt.Columns.Add("SellingAmount", typeof(string));
            dt.Columns.Add("LAmount", typeof(string));
            return dt;
        }

        public static void ETNNonTradeInsert(List<string> LastTDateList)  //寫入ETNTradingBroker Table(10.60.0.39 ETFData)
        {
            foreach (string lastTDate in LastTDateList)
            {
                Console.WriteLine(lastTDate);
                try
                {
                    //DateTime datetime_lastTDate = TradeDate.LastNTradeDate(1);
                    //List<string> ETNList = new List<string>();
                    List<string> ETNTradeList = new List<string>();
                    //List<string> ETNNonTradeList = new List<string>();

                    /// <summary>
                    /// 找到ETN發行商當天進出的ETNID清單
                    /// </summary>
                    string sqlStr = "SELECT * FROM [ETFData].[dbo].[ETNTradingBroker] "
                    + $" where [TDate]='{lastTDate}' and [IssuerID]=[BrokerID] "
                    + " order by [TDate], [ETNID] ";

                    SqlConnection conn = new SqlConnection("Data Source=10.60.0.39;Initial Catalog=ETFData;User ID=WarrantWeb;Password=WarrantWeb");
                    TradeETN = EDLib.SQL.MSSQL.ExecSqlQry(sqlStr, conn, null);
                    //Utility.SaveToCSV(TradeETN, ".\\NonTradeETN.csv", true);

                    string aa = lastTDate;
                    //將名單加到List
                    foreach (DataRow row in TradeETN.Rows)
                    {
                        aa = row["TDate"].ToString();
                        ETNTradeList.Add(row["ETNID"].ToString());
                    }


                    /// <summary>
                    /// 找到所有已上市,未到期ETNID清單
                    /// </summary>
                    string sqlStrCmoney = "SELECT * from ETN基本資料表 "
                    + $" where 上市日期<='{lastTDate}' and 到期日期>='{lastTDate}' and 年度='{lastTDate.Substring(0, 4)}' "
                    + " order by 股票代號 ";

                    etnBasicData = MyCSharpLib.CMoney.ExecCMoneyQry(sqlStrCmoney);
                    //Utility.SaveToCSV(etnBasicData, ".\\etnBasicData.csv", true);
                    

                    NonTradeETN = InitializeTables();

                    foreach (DataRow row in etnBasicData.Rows)
                    {
                        //ETNList.Add(row["股票代號"].ToString());
                        if (ETNTradeList.Contains(row["股票代號"].ToString()) == false)  //若該檔ETNID發行商當日無交易
                        {
                            //ETNNonTradeList.Add(row["股票代號"].ToString());  //將該檔ETNID加入ETNNonTradeList清單
                            
                            //新增資料到NonTradeETN DataTable
                            DataRow newRow = NonTradeETN.NewRow();
                            //newRow["TDate"] = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
                            newRow["TDate"] = lastTDate.ToString();
                            newRow["IssuerID"] = row["券商代號"].ToString();
                            newRow["IssuerName"] = row["券商名稱"].ToString();
                            newRow["ETNID"] = row["股票代號"].ToString();
                            newRow["ETNName"] = row["股票名稱"].ToString();
                            newRow["BrokerID"] = row["券商代號"].ToString();   //BrokerID=IssuerID
                            newRow["BuyingLots"] = 0;      //因為當天發行商(自營商)無交易, 所以寫入0
                            newRow["BuyingAmount"] = 0;    //因為當天發行商(自營商)無交易, 所以寫入0
                            newRow["SellingLots"] = 0;     //因為當天發行商(自營商)無交易, 所以寫入0
                            newRow["SellingAmount"] = 0;   //因為當天發行商(自營商)無交易, 所以寫入0
                            newRow["LAmount"] = "N";
                            NonTradeETN.Rows.Add(newRow);
                        }
                    }
                    Utility.SaveToCSV(NonTradeETN, $".\\{lastTDate}_NonTradeETN.csv", true);
                    //Console.WriteLine("ETN Issuer NonTrade Fake Data Insert complete!\n");
                    /// <summary>
                    /// 寫入資料庫
                    /// </summary>
#if !DEBUG
                    using (conn)
                    {
                        conn.Open();
                        Console.WriteLine($"Inserting ETNTradingBroker NonTradeETN Data of {lastTDate}");
                        foreach (DataRow row in NonTradeETN.Rows)
                        {
                            Console.WriteLine(row[0].ToString());
                            string SQLcmd = $@"Insert into ETNTradingBroker(TDate, IssuerID, IssuerName, ETNID,  ETNName, BrokerID, BuyingLots, SellingLots, BuyingAmount, SellingAmount, LAmount) Values("
                                    + $"'{row[0].ToString()}','{row[1].ToString()}', '{row[2].ToString()}','{row[3].ToString()}', '{row[4].ToString()}', '{row[5].ToString()}', '{row[6]}', '{row[7]}', '{row[8]}', '{row[9]}', '{row[10].ToString()}')";
                            EDLib.SQL.MSSQL.ExecSqlCmd(SQLcmd, conn);
                            //Console.WriteLine(SQLcmd);
                        }
                    }
#endif

                    Console.WriteLine("ETN Issuer NonTrade Fake Data Insert complete!\n");

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
            }
                

        }

        public static void ETNBasicDataUpdater(List<string> LastTDateList)
        {
            foreach (string lastTDate in LastTDateList)
            {
                Console.WriteLine(lastTDate);
                try
                {
                    string sqlStr = "SELECT [年度],[股票代號],[股票名稱],[中文名稱],[英文名稱],[英文簡稱],[發行日期],[上市日期],[最後交易日],[到期日期],[發行年限],[發行單位數(百萬)],[發行價格],[發行總額(百萬)],[ETN類型],[標的區域代號],[標的區域],[追蹤指數中文名稱],[追蹤指數英文名稱],[追蹤指數對應代號],[指數編製機構],[上市上櫃],[槓桿倍數],[國際證券編碼],[標的指數含國外證券],[是否配息],[交易幣別],[追蹤指數幣別],[交易單位],[交易價格],[升降單位],[漲跌幅度(%)],[交易時間],[證券交易稅(%)],[年投資手續費],[券商代號],[券商名稱],[申購賣回方式],[申購賣回條件],[申購賣回申報時間],[申購賣回基本單位],[指標價值達上限(元)],[指標價值達下限(元)],[指標價值達發行價格上限比例(%)大於],[指標價值達發行價格上限比例(%)等於],[指標價值達發行價格下限比例(%)小於],[指標價值達發行價格下限比例(%)等於],[強制贖回其他條件],[提前贖回條件],[終止上市日],[終止上市原因],[備註],[RTIME]"
                           + "from ETN基本資料表 where 年度= " + $"'{lastTDate.Substring(0, 4)}' ";
                    etnBasicData = MyCSharpLib.CMoney.ExecCMoneyQry(sqlStr);
                    //Utility.SaveToCSV(etnBasic, ".\\etnBasic.csv", true);
                    Console.WriteLine(lastTDate);

#if !DEBUG
                    string updatTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    using (SqlConnection conn = new SqlConnection("Data Source=10.60.0.39;Initial Catalog=ETFData;User ID=WarrantWeb;Password=WarrantWeb"))
                    {
                        conn.Open();
                        EDLib.SQL.MSSQL.ExecSqlCmd($"DELETE FROM ETNBasicData WHERE 年度='{lastTDate.Substring(0, 4)}' ", conn);
                        Console.WriteLine($"Inserting ETNBasicData of {lastTDate.Substring(0, 4)}");
                        foreach (DataRow row in etnBasicData.Rows)
                        {

                            string SQLcmd = $@"Insert into ETNBasicData( [年度],[股票代號],[股票名稱],[中文名稱],[英文名稱],[英文簡稱],[發行日期],[上市日期],[最後交易日],[到期日期],[發行年限],[發行單位數(百萬)],[發行價格],[發行總額(百萬)],"
                                   + " [ETN類型],[標的區域代號],[標的區域],[追蹤指數中文名稱],[追蹤指數英文名稱],[追蹤指數對應代號],[指數編製機構],[上市上櫃],[槓桿倍數],[國際證券編碼],[標的指數含國外證券],"
                                   + " [是否配息],[交易幣別],[追蹤指數幣別],[交易單位],[交易價格],[升降單位],[漲跌幅度(%)],[交易時間],[證券交易稅(%)],[年投資手續費],[券商代號],[券商名稱],"
                                   + " [申購賣回方式],[申購賣回條件],[申購賣回申報時間],[申購賣回基本單位],[指標價值達上限(元)],[指標價值達下限(元)],"
                                   + " [指標價值達發行價格上限比例(%)大於],[指標價值達發行價格上限比例(%)等於],[指標價值達發行價格下限比例(%)小於],[指標價值達發行價格下限比例(%)等於],[強制贖回其他條件],[提前贖回條件],"
                                   + " [終止上市日],[終止上市原因],[備註],[MTIME]) Values("
                                   + $" '{row[0].ToString()}','{row[1].ToString()}','{row[2].ToString()}','{row[3].ToString()}','{row[4].ToString()}','{row[5].ToString()}','{row[6].ToString()}','{row[7].ToString()}','{row[8].ToString()}','{row[9].ToString()}','{row[10]}',"
                                   + $" '{row[11]}','{row[12]}','{row[13]}','{row[14].ToString()}','{row[15].ToString()}','{row[16].ToString()}','{row[17].ToString()}','{row[18].ToString()}','{row[19].ToString()}','{row[20].ToString()}',"
                                   + $" '{row[21]}','{row[22]}','{row[23].ToString()}','{row[24].ToString()}','{row[25].ToString()}','{row[26].ToString()}','{row[27].ToString()}','{row[28].ToString()}','{row[29].ToString()}','{row[30].ToString()}',"
                                   + $" '{row[31].ToString()}','{row[32].ToString()}','{row[33].ToString()}','{row[34].ToString()}','{row[35].ToString()}','{row[36].ToString()}','{row[37].ToString()}','{row[38].ToString()}','{row[39].ToString()}','{row[40].ToString()}',"
                                   + $" '{row[41].ToString()}','{row[42].ToString()}','{row[43].ToString()}','{row[44].ToString()}','{row[45].ToString()}','{row[46].ToString()}','{row[47].ToString()}','{row[48].ToString()}','{row[49].ToString()}','{row[50].ToString()}',"
                                   + $" '{row[51].ToString()}','{updatTime.ToString()}')";



                            EDLib.SQL.MSSQL.ExecSqlCmd(SQLcmd, conn);
                        }

                        //Console.WriteLine(SQLcmd);

                        Console.WriteLine("ETNBasicData Insert Complete");
                    }
#endif
                }
                catch (Exception e)
                {
                    MailService ms = new MailService();
                    ms.SendMail("lecheng@kgi.com", "10.60.0.39 ERROR", new string[] { "lecheng@kgi.com" }, null, null, $"{lastTDate}ETFTradingBroker ERROR!", e.ToString(), false, null);

                }
            }
                
        }

        public static void ETNTradingBrokerCalculator(List<string> LastTDateList)  //寫入ETNTradingBroker Table(10.60.0.39 ETFData)
        {
            foreach (string lastTDate in LastTDateList)
            {
                Console.WriteLine(lastTDate);
                try
                {
                    //個股券商分點進出明細=>經紀+自營
                    //個股券商進出明細=>經紀+鉅額
                    //個股券商分點進出明細-個股券商進出明細=自營
                    string sqlStr = "SELECT A.日期, D.券商代號, D.券商名稱, A.股票代號, D.股票名稱, E.總公司代號, Sum(A.買張)-isnull(C.買張,0) as buy , (Sum(A.賣張)-isnull(C.賣張,0)) * -1 as sell, Sum(A.張增減)-isnull(C.張增減,0) as netbs "
                    + " ,Sum(A.[買金額(千)])-isnull(C.[買金額(千)],0) as buyA, (Sum(A.[賣金額(千)])-isnull(C.[賣金額(千)],0)) * -1 as sellA, Sum(A.[金額增減(千)])-isnull(C.[金額增減(千)],0) as netbsA "
                    + " from 個股券商分點進出明細 as A "
                    + " left join ETN基本資料表 as D on D.股票代號=A.股票代號 "
                    + " left join 券商公司基本資料表 as E on A.券商代號=E.代號 "
                    + " left join 個股券商進出明細 as C on C.股票代號=A.股票代號 and E.總公司代號=C.券商代號 and A.日期=C.日期 "
                    + $" where A.日期='{lastTDate}' and D.年度='{lastTDate.Substring(0, 4)}' and E.年度='{lastTDate.Substring(0, 4)}' "
                    + " group by A.日期, D.券商代號, D.券商名稱, A.股票代號, E.總公司代號, D.股票名稱 , C.買張 , C.賣張, C.張增減, C.[買金額(千)], C.[賣金額(千)], C.[金額增減(千)] "
                    + " having Sum(A.買張)-isnull(C.買張,0)<>0 or Sum(A.賣張)-isnull(C.賣張,0)<>0 or Sum(A.張增減)-isnull(C.張增減,0)<>0 or Sum(A.[買金額(千)])-isnull(C.[買金額(千)],0)<>0 or Sum(A.[賣金額(千)])-isnull(C.[賣金額(千)],0)<>0 or Sum(A.[金額增減(千)])-isnull(C.[金額增減(千)],0) <>0"
                    + " order by A.股票代號 ";

                    etfMM = MyCSharpLib.CMoney.ExecCMoneyQry(sqlStr);
                    etfMM.Columns.Add("Lamount", typeof(string));
                    foreach (DataRow row in etfMM.Rows)
                    {
                        row["Lamount"] = "N";
                    }

                    //鉅額交易(僅包含經紀單位,不含純自營部門的資料)
                    sqlStr = "SELECT A.日期, D.券商代號, D.券商名稱, A.股票代號, D.股票名稱, E.總公司代號, A.買張 as buy , (A.賣張) * -1 as sell, A.張增減 as netbs "
                    + " ,A.[買金額(千)] buyA, (A.[賣金額(千)]) * -1 as sellA, A.[金額增減(千)] as netbsA "
                    + " from 個股券商分點進出鉅額明細 as A "
                    + " left join ETN基本資料表 as D on D.股票代號=A.股票代號 "
                    + " left join 券商公司基本資料表 as E on A.券商代號 = E.代號 "
                    + $" where A.日期='{lastTDate}' and D.年度='{lastTDate.Substring(0, 4)}' and E.年度='{lastTDate.Substring(0, 4)}' "
                    + " and isnull(D.股票代號, '1') <> '1' and A.券商代號 = E.總公司代號"
                    + " order by A.股票代號 ";

                    etfMML = MyCSharpLib.CMoney.ExecCMoneyQry(sqlStr);
                    Utility.SaveToCSV(etfMM, ".\\etn.csv", true);
                    Utility.SaveToCSV(etfMML, ".\\etnL.csv", true);

                    if (etfMML.Rows.Count > 0)
                    {
                        etfMML.Columns.Add("Lamount", typeof(string));
                        foreach (DataRow row in etfMML.Rows)
                        {
                            row["Lamount"] = "Y";
                        }
                        summary = etfMM.AsEnumerable().Union(etfMML.AsEnumerable()).CopyToDataTable();
                    }
                    else
                    {
                        summary = etfMM;
                    }

                    Utility.SaveToCSV(summary, ".\\etnSummary.csv", true);
#if !DEBUG
                    using (SqlConnection conn = new SqlConnection("Data Source=10.60.0.39;Initial Catalog=ETFData;User ID=WarrantWeb;Password=WarrantWeb"))
                    {
                        conn.Open();
                        EDLib.SQL.MSSQL.ExecSqlCmd($"DELETE FROM ETNTradingBroker WHERE TDate>='{lastTDate}' and TDate<='{lastTDate} 23:59'", conn);
                        Console.WriteLine($"Inserting ETNTradingBroker of {lastTDate}");
                        foreach (DataRow row in summary.Rows)
                        {
                            string SQLcmd = $@"Insert into ETNTradingBroker(TDate, IssuerID, IssuerName, ETNID,  ETNName, BrokerID, BuyingLots, SellingLots, BuyingAmount, SellingAmount, LAmount) Values("
                                    + $"'{row[0].ToString()}','{row[1].ToString()}', '{row[2].ToString()}','{row[3].ToString()}', '{row[4].ToString()}', '{row[5].ToString()}', {row[6].ToString()}, {row[7].ToString()}, {row[9].ToString()}, {row[10].ToString()}, '{row[12].ToString()}')";
                            EDLib.SQL.MSSQL.ExecSqlCmd(SQLcmd, conn);
                            //Console.WriteLine(SQLcmd);
                        }
                    }
#endif
                }
                catch (Exception e)
                {
                    //Console.ReadLine();
                    MailService ms = new MailService();
                    ms.SendMail("lecheng@kgi.com", "10.60.0.39 ERROR", new string[] { "lecheng@kgi.com" }, null, null, $"{lastTDate}ETFTradingBroker ERROR!", e.ToString(), false, null);
                }
            }

        }

        public static void ETNBrokerCalculator(List<string> LastTDateList)  //寫入ETNBroker Table(10.60.0.39 ETFData)
        {
            
            foreach (string lastTDate in LastTDateList)
            {
                Console.WriteLine(lastTDate);
                Console.WriteLine("Cmoney Data Query Begins...");

                try
                {
                    //個股券商分點進出明細=>經紀+自營
                    string sqlStr = "SELECT A.日期, D.券商代號, D.券商名稱, A.股票代號, D.股票名稱, E.總公司代號, A.券商代號 as 券商代號2, A.券商名稱 as 券商名稱2, isnull(A.買張,0) as buy , isnull(A.賣張,0) * -1 as sell, isnull(A.張增減,0) as netbs "
                    + " ,isnull(A.[買金額(千)],0) as buyA, isnull(A.[賣金額(千)],0) * -1 as sellA, isnull(A.[金額增減(千)],0) as netbsA "
                    + " from 個股券商分點進出明細 as A "
                    + " left join ETN基本資料表 as D on D.股票代號=A.股票代號 "
                    + " left join 券商公司基本資料表 as E on A.券商代號=E.代號 "
                    + $" where A.日期='{lastTDate}' and D.年度='{lastTDate.Substring(0, 4)}' and E.年度='{lastTDate.Substring(0, 4)}'  "
                    + " order by A.股票代號, E.總公司代號, A.券商代號 ";


                    etnBroker = MyCSharpLib.CMoney.ExecCMoneyQry(sqlStr);
                    Utility.SaveToCSV(etnBroker, $".\\etnBroker_{lastTDate}.csv", true);
                    Console.WriteLine("Cmoney Data Output to CSV Complete...");

                    #region 整理到DataTable


                    #endregion

                    #region 寫入資料庫
#if !DEBUG
                    using (SqlConnection conn = new SqlConnection("Data Source=10.60.0.39;Initial Catalog=ETFData;User ID=WarrantWeb;Password=WarrantWeb"))
                    {
                        conn.Open();
                        //MSSQL.ExecSqlCmd($"DELETE FROM ETFBroker WHERE TDate>='{lastTDate}' and TDate<='{lastTDate} 23:59'", conn);
                        Console.WriteLine($"Inserting ETFBroker of {lastTDate}");
                        foreach (DataRow row in etnBroker.Rows)
                        {

                            string SQLcmd = $@"Insert into ETNBroker(TDate, IssuerID, IssuerName, ETNID,  ETNName, BrokerID, BrokerSubID, BrokerSubName, BuyingLots, SellingLots, BuyingAmount, SellingAmount) Values("
                                + $"'{row[0].ToString()}','{row[1].ToString()}', '{row[2].ToString()}', '{row[3].ToString()}', '{row[4].ToString()}', '{row[5].ToString()}', '{row[6].ToString()}', '{row[7].ToString()}', {row[8].ToString()}, {row[9].ToString()}, {row[11].ToString()}, {row[12].ToString()})";
                            EDLib.SQL.MSSQL.ExecSqlCmd(SQLcmd, conn);
                        }

                        //Console.WriteLine(SQLcmd);

                        Console.WriteLine("Cmoney Data Insert Complete");
                    }
#endif
                    #endregion

                }
                catch (Exception e)
                {
                    //Console.ReadLine();
                    MailService ms = new MailService();
                    ms.SendMail("lecheng@kgi.com", "10.60.0.39 ERROR", new string[] { "lecheng@kgi.com" }, null, null, $"{lastTDate}ETFBroker ERROR!", e.ToString(), false, null);

                }
            }
        }

        public static void MailSender()
        {
            string mailFrom = ConfigurationManager.AppSettings["mailFrom"].ToString();
            string mailTo = ConfigurationManager.AppSettings["mailTo"].ToString();
            try
            {
                string updatTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                MailService ms = new MailService();
                ms.SendMail("lecheng@kgi.com", "ETNBroker_Class", new string[] { "licheng@kgi.com" }, null, null, $"{updatTime} 主旨", "內文Body", false, null);
                Console.WriteLine("郵件寄送完成");
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

        }

        
    }

}
