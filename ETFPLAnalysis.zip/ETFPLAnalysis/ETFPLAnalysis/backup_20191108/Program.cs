﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EDLib;
using EDLib.SQL;

namespace ETFPLAnalysis
{
    class Program
    {
        static string RecTime = DateTime.Now.ToString("HH:mm:ss");
        static string lastTDate = TradeDate.LastNTradeDate(2).ToString("yyyy/M/dd");
        static string outputFileName = TradeDate.LastNTradeDate(2).ToString("yyyyMMdd");
        static string lastTwoDate = TradeDate.LastNTradeDate(3).ToString("yyyy/M/dd");
        //static string lastTDate = "20190916";
        static List<string> LastTDateList = new List<string>();
        static List<string> LastTwoDateList = new List<string>();

        static void Main(string[] args)
        {
            //LastTDateList.Add(lastTDate);
            //LastTDateList.Add("20191001");
            //LastTDateList.Add("20191002");
            //LastTDateList.Add("20191003");
            //LastTDateList.Add("20191004");
            //LastTDateList.Add("20191007");
            //LastTDateList.Add("20191008");
            //LastTDateList.Add("20191009");
            //LastTDateList.Add("20191014");
            //LastTDateList.Add("20191015");
            //LastTDateList.Add("20191016");
            //LastTDateList.Add("20191017");
            //LastTDateList.Add("20191018");
            //LastTDateList.Add("20191021");
            //LastTDateList.Add("20191022");
            //LastTDateList.Add("20191023");
            //LastTDateList.Add("20191024");
            //LastTDateList.Add("20191025");
            //LastTDateList.Add("20191028");
            //LastTDateList.Add("20191029");
            LastTDateList.Add("20191030");

            //****LastTwoDate
            //LastTwoDateList.Add(lastTwoDate);
            //LastTwoDateList.Add("20190930");
            //LastTwoDateList.Add("20191001");
            //LastTwoDateList.Add("20191002");
            //LastTwoDateList.Add("20191003");
            //LastTwoDateList.Add("20191004");
            //LastTwoDateList.Add("20191007");
            //LastTwoDateList.Add("20191008");
            //LastTwoDateList.Add("20191009");
            //LastTwoDateList.Add("20191014");
            //LastTwoDateList.Add("20191015");
            //LastTwoDateList.Add("20191016");
            //LastTwoDateList.Add("20191017");
            //LastTwoDateList.Add("20191018");
            //LastTwoDateList.Add("20191021");
            //LastTwoDateList.Add("20191022");
            //LastTwoDateList.Add("20191023");
            //LastTwoDateList.Add("20191024");
            //LastTwoDateList.Add("20191025");
            //LastTwoDateList.Add("20191028");
            LastTwoDateList.Add("20191029");
            //LastTwoDateList.Add("20191030");

            Console.WriteLine("LastDate is :" + lastTDate);
            //Console.WriteLine("Today is :" + TDate);
            Console.WriteLine("ETF PL Analysis Query Begins...");
            PLAnalysis.ETF_plAnalyzer(LastTDateList);


            Console.WriteLine("ETF PL Analysis Down...");
            Console.WriteLine("Bye~~");
        }

        class PLAnalysis
        {
            static DataTable etfvwDailyPL;
            static DataTable etfsummary;
            static DataTable InitializeTables()
            {
                DataTable dt = new DataTable();
                //dt.Columns.Add("TDate", typeof(DateTime));
                //dt.Columns.Add("IssuerID", typeof(string));
                //dt.Columns.Add("IssuerName", typeof(string));
                //dt.Columns.Add("ETNID", typeof(string));
                //dt.Columns.Add("ETNName", typeof(string));
                //dt.Columns.Add("BrokerID", typeof(string));
                //dt.Columns.Add("BuyingLots", typeof(string));
                //dt.Columns.Add("BuyingAmount", typeof(string));
                //dt.Columns.Add("SellingLots", typeof(string));
                //dt.Columns.Add("SellingAmount", typeof(string));
                //dt.Columns.Add("LAmount", typeof(string));
                return dt;
            }

            public static void ETF_plAnalyzer(List<string> LastTDateList)  //寫入ETNTradingBroker Table(10.19.1.45 testEDIS)
            {
                foreach (string lastTDate in LastTDateList)
                {
                    string outputFileName = "";
                    int i = LastTDateList.IndexOf(lastTDate);    //找到當天交易日在List中的位置
                    string lastTwoDate = LastTwoDateList[i];     //前一天交易日所對應同位置的index
                    Console.WriteLine("當天交易日期:  " + lastTDate);           //所欲計算的交易日
                    Console.WriteLine("前一天交易日期:" + LastTwoDateList[i]);  //計算日的前一交易日
                    if (lastTDate.Length > 8)
                    {
                        outputFileName = DateTime.Parse(lastTDate).ToString("yyyyMMdd");
                    }
                    else
                    {
                        outputFileName = lastTDate;
                    }
                   
                        

                    Console.WriteLine("Wait...");
                    try
                    {
                        SqlConnection conn1 = new SqlConnection("Data Source=10.60.0.37;Initial Catalog=DeriPosition;User ID=WarrantWeb;Password=WarrantWeb");
                        conn1.Open();
                        #region 整理ETF_plData_SQL
                        string sqlStr = "select S1.TradeDate as DataDate,S1.TraderNm,S1.gaccountid,S1.newIAccountId as NaccountId,S1.IAccountId,S1.CommodityId,S1.CommodityNm,S1.Strategy,S1.CommodityKind,S1.hedgeLinkId,S1.hedgeLinkName,S1.CurrencyId,S1.ContractSize,S1.Unit, "
                        + "S1.tCashDivAdj,S1.yInvShare, " 
                        + "S1.yInvShare+S1.BuyQty+S1.CreBuyQty+S1.SEditBuyQty-(S1.SellQty+S1.RedSellQty+S1.SEditSellQty) as tInvShare, "
                        + "S1.BuyQty+S1.CreBuyQty as TBuyQty, "
                        + "S1.BuyAmt+S1.CreBuyAmt as TBuyAmt, "
                        + "case when S1.BuyQty+S1.CreBuyQty+S1.SEditBuyQty=0 then 0 else (S1.BuyAmt+S1.CreBuyAmt+S1.SEditBuyAmt)/(S1.BuyQty+S1.CreBuyQty+S1.SEditBuyQty)/S1.ContractSize end as TBuyAvgPrice, "
                        + "S1.SellQty+S1.RedSellQty as TSellQty, "
                        + "S1.SellAmt+S1.RedSellAmt as TSellAmt, "
                        + "case when S1.SellQty+S1.RedSellQty+S1.SEditSellQty=0 then 0 else (S1.SellAmt+S1.RedSellAmt+S1.SEditSellAmt)/(S1.SellQty+S1.RedSellQty+S1.SEditSellQty)/S1.ContractSize end as TSellAvgPrice, "
                        //+ "S1.BuyQty,S1.CreBuyQty,S1.BuyQty+S1.CreBuyQty as TBuyQty, " 
                        //+ "S1.BuyAmt,S1.CreBuyAmt,S1.BuyAmt+S1.CreBuyAmt as TBuyAmt, "
                        //+ "S1.BuyAvgPrice,S1.CreBuyAvgPrice,case when S1.BuyQty+S1.CreBuyQty=0 then 0 else (S1.BuyAmt+S1.CreBuyAmt)/(S1.BuyQty+S1.CreBuyQty) end as TBuyAvgPrice, "
                        //+ "S1.SellQty,S1.RedSellQty,S1.SellQty+S1.RedSellQty as TSellQty, "
                        //+ "S1.SellAmt,S1.RedSellAmt,S1.SellAmt+S1.RedSellAmt as TSellAmt, "
                        //+ "S1.SellAvgPrice,S1.RedSellAvgPrice,case when S1.SellQty+S1.RedSellQty=0 then 0 else (S1.SellAmt+S1.RedSellAmt)/(S1.SellQty+S1.RedSellQty) end as TSellAvgPrice, "
                        + "S1.tNAV,S1.tPrice,S1.yNAV,S1.yPrice,S1.tSpread, "
                        + "S1.ySpread,S1.tSpreadChg,S1.tNAVChg,S1.tPriceChg,S1.tFXRate,S1.yFXRate,S1.tFXRateChg,S1.tFXRatePctChg, "
                        //+ "S1.USD,S1.CNY,S1.HKD,S1.JPY,S1.EUR,S1.KRW,"
                        + "S1.USDExposure_NTD,S1.USDFXPctChg,S1.CNYExposure_NTD,S1.CNYFXPctChg,S1.JPYExposure_NTD,S1.JPYFXPctChg, "
                        + "S1.SpreadChgPL, S1.NewPosSpreadChgPL, S1.ETFUSDChgPL, S1.ETFCNYChgPL, S1.ETFJPYChgPL, S1.FutFXChgPL,(S1.ETFUSDChgPL+S1.ETFCNYChgPL+S1.ETFJPYChgPL+S1.FutFXChgPL) as FXChgPL, "
                        + "S1.SpreadChgPL+S1.NewPosSpreadChgPL as TotalSpreadChgPL,S1.SpreadChgPL-(S1.ETFUSDChgPL+S1.ETFCNYChgPL+S1.ETFJPYChgPL+S1.FutFXChgPL) as SpreadChgPL_dFX, "
                        + "S1.SpreadChgPL+S1.NewPosSpreadChgPL-(S1.ETFUSDChgPL+S1.ETFCNYChgPL+S1.ETFJPYChgPL+S1.FutFXChgPL) as TotalSpreadChgPL_dFX, "
                        + "S1.NetDeltaPL as NetDeltaPL,S1.DayTradePL,(S1.SpreadChgPL+S1.NewPosSpreadChgPL+S1.NetDeltaPL+S1.DayTradePL) as totalDailyPL,S1.tTotalCost,S1.tDOtherIncome,S1.tDTradePL,S1.tDNetTradePL, "
                        + $"1 as TimeCategory, '{RecTime}' as RecTime "
                        + "from "
                        + "(select T1.*,case when T1.FCurrency1='USD' then T1.yInvShare*T1.yNAV*(T1.USD+T1.HKD) else 0 end as USDExposure_USD  "
                        + ",case when T1.FCurrency2='CNY' then T1.yInvShare*T1.yNAV*(T1.CNY) else 0 end as CNYExposure_CNY "
                        + ",case when T1.FCurrency3='JPY' then T1.yInvShare*T1.yNAV*(T1.JPY) else 0 end as JPYExposure_JPY "
                        + ",case when T1.FCurrency1='NTD' then 1 else tUSD.NAV end as tUSDFX "
                        + ",case when T1.FCurrency1='NTD' then 1 else yUSD.NAV end as yUSDFX "
                        + ",case when T1.FCurrency2='NTD' then 1 else tCNY.NAV end as tCNYFX "
                        + ",case when T1.FCurrency2='NTD' then 1 else yCNY.NAV end as yCNYFX "
                        + ",case when T1.FCurrency3='NTD' then 1 else tJPY.NAV end as tJPYFX "
                        + ",case when T1.FCurrency3='NTD' then 1 else yJPY.NAV end as yJPYFX "
                        + ",case when T1.CommodityKind='ETF' then T1.yInvShare*(T1.tSpread-T1.ySpread)*(T1.tFXRate) else 0 end as SpreadChgPL "
                        + ",case when T1.CommodityKind='ETF' then T1.yInvShare*T1.yNAV*(T1.USD+T1.HKD)*((case when T1.FCurrency1='NTD' then 1 else tUSD.NAV end)/(case when T1.FCurrency1='NTD' then 1 else yUSD.NAV end)-1)*T1.tFXRate else 0 end as ETFUSDChgPL "
                        + ",case when T1.CommodityKind='ETF' then T1.yInvShare*T1.yNAV*(T1.CNY)*((case when T1.FCurrency2='NTD' then 1 else tCNY.NAV end)/(case when T1.FCurrency2='NTD' then 1 else yCNY.NAV end)-1)*T1.tFXRate else 0 end as ETFCNYChgPL "
                        + ",case when T1.CommodityKind='ETF' then T1.yInvShare*T1.yNAV*(T1.JPY)*((case when T1.FCurrency3='NTD' then 1 else tJPY.NAV end)/(case when T1.FCurrency3='NTD' then 1 else yJPY.NAV end)-1)*T1.tFXRate else 0 end as ETFJPYChgPL "
                        + ",case when T1.CommodityKind='ETF' then 0 else T1.yInvShare*(T1.tPriceChg)*(T1.ContractSize)*(T1.tFXRateChg) end as FutFXChgPL "
                        + ",case when T1.CommodityKind='ETF' then T1.yInvShare*(T1.tNAVChg) else (T1.yInvShare*(T1.tPriceChg)*(T1.ContractSize) +T1.yCashDivAmt)*(tFXRate) end as NetDeltaPL "
                        + ",(case when T1.BuyQty-T1.SellQty>0 then T1.BuyQty-T1.SellQty else 0 end)*(T1.tPrice-T1.BuyAvgPrice)*(tFXRate)*(T1.ContractSize) "
                        + "+(case when T1.SellQty-T1.BuyQty>0 then T1.SellQty-T1.BuyQty else 0 end)*(T1.SellAvgPrice-T1.tPrice)*(tFXRate)*(T1.ContractSize) as NewPosSpreadChgPL "
                        + ",(case when T1.BuyQty<T1.SellQty then T1.BuyQty else T1.SellQty end)*(T1.tPrice-T1.BuyAvgPrice)*(tFXRate)*(T1.ContractSize) "
                        + "+(case when T1.BuyQty<T1.SellQty then T1.BuyQty else T1.SellQty end)*(T1.SellAvgPrice-T1.tPrice)*(tFXRate)*(T1.ContractSize) as DayTradePL "
                        + ",T1.yInvShare*T1.yNAV*(T1.USD+T1.HKD)*T1.tFXRate as USDExposure_NTD "
                        + ",T1.yInvShare*T1.yNAV*(T1.CNY)*T1.tFXRate as CNYExposure_NTD "
                        + ",T1.yInvShare*T1.yNAV*(T1.JPY)*T1.tFXRate as JPYExposure_NTD "
                        + ",case when (T1.USD=0 and T1.HKD=0) then 0 else (tUSD.NAV/ yUSD.NAV)-1 end as USDFXPctChg "
                        + ",case when T1.CNY=0 then 0 else (tCNY.NAV/ yCNY.NAV)-1 end as CNYFXPctChg "
                        + ",case when T1.JPY=0 then 0 else (tJPY.NAV/ yJPY.NAV)-1 end as JPYFXPctChg "
                        + "from "
                        + "(SELECT CONVERT(varchar(10), A.[TradeDate],111) as TradeDate,A.[TraderNm],A.[gaccountid] "
                        + ",case when (left(A.[IAccountId],2)='07' or left(A.[IAccountId],2)='0H') then right(A.[IAccountId],3) else left(A.[IAccountId],3) end as newIAccountId "
                        + ",A.[IAccountId],A.[CommodityId],A.[CommodityNm] "
                        + ",case when (A.[CommodityId]='00677U' or left(A.[CommodityId],2)='VX') then 'VIX' "
                        + "when (A.[CommodityId] in ('00672L','00673R') or left(A.[CommodityId],2)='CL') then '商品' "
                        + "else I.[Strategy] end as Strategy "
                        + ",A.[CommodityKind],A.[CurrencyId] "
                        + ",case when A.CommodityKind='Future' then  A.[ContractSize] else 1 end as ContractSize, A.[Unit] "
                        + ",isnull(J.[InvShare],0)-isnull(L.BuyQty,0)+isnull(L.SellQty,0) as yInvShare "
                        + ",A.[InvShare] as tInvShare  ,A.[MPrice] as tMPrice,A.[MV] as tMV "
                        + ",case when (right(A.IAccountId,1)='U' or right(A.IAccountId,1)='S') then 0 else isnull(A.[BuyShare],0) end as BuyQty "
                        + ",isnull(A.[BuyAmt],0) as BuyAmt "
                        + ",isnull(A.[SellShare],0) as SellQty,isnull(A.[SellAmt],0) as SellAmt "
                        //+ ",isnull(case when A.[CommodityNm]='白銀期貨' then A.[BuyAvgP]/100 else A.[BuyAvgP] end,0) as BuyAvgPrice "
                        //+ ",isnull(case when A.[CommodityNm]='白銀期貨' then A.[SellAvgP] /100 else A.[SellAvgP] end,0) as SellAvgPrice "
                        + ",isnull(case when A.[CommodityNm]='白銀期貨' then A.[BuyAvgP]/100 "
                        + "when  A.[BuyAvgP]=0 and A.[BuyShare]<>0 then A.[BuyAmt]/A.[BuyShare] "
                        + "else A.[BuyAvgP] end,0) as BuyAvgPrice "
                        + ",isnull(case when A.[CommodityNm]='白銀期貨' then A.[SellAvgP] /100 "
                        + "when A.[SellAvgP]=0 and A.[SellShare]<>0 then A.[SellAmt]/A.[SellShare] "
                        + "else A.[SellAvgP] end,0) as SellAvgPrice "
                        + ",isnull(L.BuyAmt,0) as CreBuyAmt, isnull(L.BuyAvgPrice,0) as CreBuyAvgPrice, isnull(L.BuyQty,0) as CreBuyQty "
                        + ",isnull(L.SellAmt,0) as RedSellAmt, isnull(L.SellAvgPrice,0) as RedSellAvgPrice, isnull(L.SellQty,0) as RedSellQty "
                        + ",isnull(B.BuyAmt,0) as SEditBuyAmt, isnull(B.BuyAvgPrice,0) as SEditBuyAvgPrice, isnull(B.BuyQty,0) as SEditBuyQty "
                        + ",isnull(C.SellAmt,0) as SEditSellAmt, isnull(C.SellAvgPrice,0) as SEditSellAvgPrice, isnull(C.SellQty,0) as SEditSellQty "
                        + ",A.[DTradePL]*(case when A.CurrencyId='NTD' then 1 else G.NAV end) as tDTradePL "
                        + ",A.[DTax]*(case when A.CurrencyId='NTD' then 1 else G.NAV end)  as tDTax "
                        + ",A.[DSettleFee]*(case when A.CurrencyId='NTD' then 1 else G.NAV end)  as tDSettleFee "
                        + ",A.[DCommission]*(case when A.CurrencyId='NTD' then 1 else G.NAV end) as tDCommission "
                        + ",A.[DStkBorrowFee]*(case when A.CurrencyId='NTD' then 1 else G.NAV end) as tDStkBorrowFee "
                        + ",A.[DInterestCost]*(case when A.CurrencyId='NTD' then 1 else G.NAV end) as tDInterestCost "
                        + ",(A.[DTax]+A.[DSettleFee]+A.[DCommission]+A.[DStkBorrowFee]+A.[DInterestCost])*(case when A.CurrencyId='NTD' then 1 else G.NAV end) as tTotalCost "
                        + ",(A.[DTradePL]-A.[DTax]-A.[DSettleFee]-A.[DCommission]-A.[DStkBorrowFee]-A.[DInterestCost])*(case when A.CurrencyId='NTD' then 1 else G.NAV end) as tDNetTradePL "
                        + ",isnull(J.[CashDivAmt],0)*(case when A.CurrencyId='NTD' then 1 else G.NAV end) as yCashDivAmt "
                        + ",A.[DOtherIncome]*(case when A.CurrencyId='NTD' then 1 else G.NAV end) as tDOtherIncome "
                        + ",A.[CashDivAmt]*(case when A.CurrencyId='NTD' then 1 else G.NAV end) as tCashDivAmt "
                        + ",A.[CashDivAdj]*(case when A.CurrencyId='NTD' then 1 else G.NAV end) as tCashDivAdj "
                        + ",A.[FxRate] as sys_yFxRate, D.NAV as tNAV, D.Price as tPrice, E.NAV as yNAV, E.Price as yPrice "
                        + ",case when A.CommodityKind='ETF' then D.Price-D.NAV else 0 end as tSpread "
                        + ",case when A.CommodityKind='ETF' then E.Price-E.NAV else 0 end as ySpread "
                        + ",case when A.CommodityKind='ETF' then (D.Price-D.NAV)-(E.Price-E.NAV) else 0 end as tSpreadChg "
                        + ",case when A.CommodityKind in ('ETF','Future','Stock') then D.NAV-E.NAV else 0 end as tNAVChg "
                        + ",case when A.CommodityKind in ('ETF','Future','Stock') then D.Price-E.Price else 0 end as tPriceChg "
                        + ",case when A.CurrencyId='NTD' then 1 else F.NAV end as tFXRate "
                        + ",case when A.CurrencyId='NTD' then 1 else G.NAV end as yFXRate "
                        + ",case when A.CurrencyId='NTD' then 0 else F.NAV-G.NAV end as tFXRateChg "
                        + ",case when A.CurrencyId='NTD' then 0 else F.NAV/G.NAV-1 end as tFXRatePctChg "
                        + ",isnull(H.USD,0) as USD  ,isnull(H.CNY,0) as CNY  ,isnull(H.HKD,0) as HKD ,isnull(H.JPY,0) as JPY ,isnull(H.EUR,0) as EUR ,isnull(H.KRW,0) as KRW "
                        + ",'USD' as FCurrency1,'CNY' as FCurrency2,'JPY' as FCurrency3,'EUR' as FCurrency4,'KRW' as FCurrency5 "
                        + ",case "
                        + "when A.CommodityKind='ETF' then K.hedgeLinkId1 "
                        + "when A.CommodityKind='Future' and left(A.CommodityId,2) in ('CL','GC','YM','NQ','ES','SI','VX','ZS','TN','UB','US') then left(A.CommodityId,2) "
                        + "when A.CommodityKind='Future' and left(A.CommodityId,3) in ('HHI','MHI','NCH','SCN','SSI','JTI','TXF','EXF','FXF','STW') then left(A.CommodityId,3) "
                        + "when A.CommodityKind='Future' and left(A.CommodityId,4) = 'LCOB' then left(A.CommodityId,4) "
                        + "when A.CommodityKind='Stock' and I.Strategy='台股' then 'TXF' "
                        + "else '' end as hedgeLinkId "
                        + ",case "
                        + "when A.CommodityKind='ETF' then K.hedgeLinkName1 "
                        + "when A.CommodityKind='Future' then A.CommodityNm "
                        + "when A.CommodityKind='Stock' and I.Strategy='台股' then '臺股期貨' "
                        + "else '' end as hedgeLinkName "
                        + "FROM [DeriPosition].[dbo].[vwDailyPL] A "
                        + "left join "
                        + "(select A.[TradeDate],A.[TraderId],A.[IAccountId],A.[CommodityId],A.[CommodityNm],A.[BS],A.TotalQty as BuyQty, "
                        + "case when A.[CommodityNm]='白銀期貨' then A.TotalAmount/100 else A.TotalAmount end as BuyAmt,cast((case when A.[CommodityNm]='白銀期貨' then A.TotalAmount/100 else A.TotalAmount end)/A.TotalQty as numeric(18,12)) as BuyAvgPrice "
                        + "from "
                        + "(SELECT [TradeDate],[TraderId],[IAccountId],[CommodityId],[CommodityNm],[BS],sum([Qty]) as TotalQty,sum([Price]*[Qty]) as TotalAmount FROM [DeriPosition].[dbo].[TradeHty] "
                        + $"where TradeDate='{lastTDate}' and TraderId in ('K31','K32','K36','W12') and BS= 'B' and IsVirtual='Y' and MUser<>'0000799' "
                        + "group by [TradeDate],[TraderId],[IAccountId],[CommodityId],[CommodityNm],[BS]) A ) B "
                        + "on A.[CommodityId]=B.[CommodityId] and A.[TraderId]=B.[TraderId] and A.[IAccountId]=B.[IAccountId] "
                        + "left join "
                        + "(select A.[TradeDate],A.[TraderId],A.[IAccountId],A.[CommodityId],A.[CommodityNm],A.[BS],A.TotalQty as SellQty, "
                        + "case when A.[CommodityNm]='白銀期貨' then A.TotalAmount/100 else A.TotalAmount end as SellAmt,cast((case when A.[CommodityNm]='白銀期貨' then A.TotalAmount/100 else A.TotalAmount end)/A.TotalQty as numeric(18,12)) as SellAvgPrice "
                        + "from "
                        + "(SELECT [TradeDate],[TraderId],[IAccountId],[CommodityId],[CommodityNm],[BS],sum([Qty]) as TotalQty,sum([Price]*[Qty]) as TotalAmount FROM [DeriPosition].[dbo].[TradeHty] "
                        + $"where TradeDate='{lastTDate}' and TraderId in ('K31','K32','K36','W12') and BS= 'S' and IsVirtual='Y' and MUser<>'0000799' "
                        + "group by [TradeDate],[TraderId],[IAccountId],[CommodityId],[CommodityNm],[BS]) A ) C "
                        + "on A.[CommodityId]=C.[CommodityId] and A.[TraderId]=C.[TraderId] and A.[IAccountId]=C.[IAccountId] "
                        + "left join "
                        + $"(select * from [10.19.1.45].[newEDIS].[dbo].[ETFValue] where ProductType in ('ETF','Futures','Stock') and DataDate='{lastTDate}' and NAV>0 and Price>0) D "
                        + "on A.CommodityId=D.ProductLink "
                        + "left join "
                        + $"(select * from [10.19.1.45].[newEDIS].[dbo].[ETFValue] where ProductType in ('ETF','Futures','Stock') and DataDate='{lastTwoDate}' and NAV>0 and Price>0) E "
                        + "on A.CommodityId=E.ProductLink "
                        + "left join "
                        + $"(select * from [10.19.1.45].[newEDIS].[dbo].[ETFValue] where ProductType='FX' and DataDate='{lastTDate}') F "
                        + "on A.currencyId=F.ProductLink "
                        + "left join "
                        + $"(select * from [10.19.1.45].[newEDIS].[dbo].[ETFValue] where ProductType='FX' and DataDate='{lastTwoDate}') G "
                        + "on A.currencyId=G.ProductLink "
                        + "left join  (SELECT ExtensionValue.CommodityId "
                        + ",SUM(CASE right(ExtensionValue.ExtensionId,3)  WHEN 'USD' THEN cast(ExtensionValue.ExtensionValue AS DECIMAL(6, 4))  ELSE 0 END) AS USD "
                        + ",SUM(CASE right(ExtensionValue.ExtensionId,3)  WHEN 'CNY' THEN cast(ExtensionValue.ExtensionValue AS DECIMAL(6, 4))  ELSE 0 END) AS CNY "
                        + ",SUM(CASE right(ExtensionValue.ExtensionId,3)  WHEN 'HKD' THEN cast(ExtensionValue.ExtensionValue AS DECIMAL(6, 4))  ELSE 0 END) AS HKD "
                        + ",SUM(CASE right(ExtensionValue.ExtensionId,3)  WHEN 'JPY' THEN cast(ExtensionValue.ExtensionValue AS DECIMAL(6, 4))  ELSE 0 END) AS JPY "
                        + ",SUM(CASE right(ExtensionValue.ExtensionId,3)  WHEN 'EUR' THEN cast(ExtensionValue.ExtensionValue AS DECIMAL(6, 4))  ELSE 0 END) AS EUR "
                        + ",SUM(CASE right(ExtensionValue.ExtensionId,3)  WHEN 'KRW' THEN cast(ExtensionValue.ExtensionValue AS DECIMAL(6, 4))  ELSE 0 END) AS KRW "
                        + "FROM DeriPosition.dbo.ExtensionValue ExtensionValue "
                        + "WHERE Left(ExtensionValue.CommodityId,2)='00' "
                        + "GROUP BY ExtensionValue.CommodityId) H "
                        + "on A.CommodityId=H.CommodityId "
                        + "left join "
                        + "(SELECT  [gaccountid],[Traderid],[Strategy] FROM [10.19.1.45].[newEDIS].[dbo].[gAccountList]) I on A.gaccountid=I.gaccountid "
                        + "left join"
                        + $"(SELECT * FROM [DeriPosition].[dbo].[vwDailyPL] WHERE TradeDate='{lastTwoDate}' and (DataSource='Stock' or (DataSource<>'Stock1' and DataSource<>'')) "
                        + "and ((strategymainid='Arb_Spd' and Traderid in ('K31','K32','K36'))"
                        + "or ( strategymainid='WMM' and Traderid = 'W12' and (CommodityId in ('00677U','00672L','00673R') or left(CommodityId,2) in ('VX','CL')))) "
                        + ") J "  //前日vwdailyPL
                        + "on A.gaccountid=J.gaccountid and A.IAccountid=J.IAccountid and A.CommodityId=J.CommodityId "
                        + "left join "
                        + "(SELECT * FROM [10.19.1.45].[newEDIS].[dbo].[hedgeAccountList]) K on A.CommodityId=K.hedgeETFId "
                        + "left join "

                        + "(SELECT  A.TradeDate, A.IAccountId, A.Kind, A.CommodityId,isnull(Creat.BookAmt,0) as BuyBookAmt, isnull((Creat.RealAmt+Creat.CommissionFee+Creat.TradeFee+Creat.TransFee),0) as BuyAmt, isnull((Creat.RealAmt+Creat.CommissionFee+Creat.TradeFee+Creat.TransFee)/Creat.Shares,0) as BuyAvgPrice, isnull(Creat.Shares,0) as BuyQty,  "
                        + "isnull(Redempt.BookAmt,0) as SellBookAmt, isnull(Redempt.SellAmt,0) as SellAmt, isnull(Redempt.SellAvgPrice,0) as SellAvgPrice, isnull(Redempt.SellQty,0) as SellQty "
                        + "FROM [PIS].[dbo].[ETFAdjust] A "
                        + "left join "
                        + $"(SELECT * FROM [PIS].[dbo].[ETFAdjust] Creat where Creat.TradeDate='{lastTwoDate}' and Creat.Kind='Creation' ) Creat "
                        + "on Creat.TradeDate=A.TradeDate and Creat.IAccountId=A.IAccountId and Creat.CommodityId=A.CommodityId "
                        + "left join "
                        + "(SELECT TradeDate, IAccountId, Kind, CommodityId, BookAmt, (RealAmt-CommissionFee-TradeFee-TransFee) as SellAmt, (RealAmt-CommissionFee-TradeFee-TransFee)/Shares as SellAvgPrice, Shares as SellQty FROM [PIS].[dbo].[ETFAdjust] "
                        + $"where TradeDate='{lastTwoDate}' and Kind='Redemption') Redempt "
                        + "on A.TradeDate=Redempt.TradeDate and A.IAccountId=Redempt.IAccountId and A.CommodityId=Redempt.CommodityId "
                        + $"where A.TradeDate='{lastTwoDate}' ) L on A.CommodityId=L.CommodityId and A.IAccountId=L.IAccountId "

                        //+ $"where A.DataSource<>'Stock1' and A.InvShare<>0 and A.strategymainid='Arb_Spd' and A.Traderid in ('K31','K32','K36') and A.TradeDate='{lastTDate}'  "
                        + $"where A.TradeDate='{lastTDate}' " 
                        + "and (A.CommodityId='00672L' or  A.CommodityId like 'CL%') "   //針對00672L測試
                        + "and (A.DataSource='Stock' or (A.DataSource<>'Stock1' and A.DataSource<>'')) "
                        + "and (( A.strategymainid='Arb_Spd' and A.Traderid in ('K31','K32','K36') and ((A.InvShare<>0 or J.InvShare<>0) or (A.InvShare=0 and J.InvShare=0 and A.BuyShare<>0 and A.SellShare<>0) ) ) "
                        + "or ( A.strategymainid='WMM' and A.Traderid = 'W12' and (A.CommodityId in ('00677U','00672L','00673R') or left(A.CommodityId,2) in ('VX','CL')) and ((A.InvShare<>0 or J.InvShare<>0) or (A.InvShare=0 and J.InvShare=0 and A.BuyShare<>0 and A.SellShare<>0)))) "
                        + ") T1 "
                        + "left join "
                        + $"(select * from [10.19.1.45].[newEDIS].[dbo].[ETFValue] where ProductType='FX' and DataDate='{lastTDate}') tUSD on T1.FCurrency1=tUSD.ProductLink "
                        + "left join "
                        + $"(select * from [10.19.1.45].[newEDIS].[dbo].[ETFValue] where ProductType='FX' and DataDate='{lastTwoDate}') yUSD on T1.FCurrency1=yUSD.ProductLink "
                        + "left join "
                        + $"(select * from [10.19.1.45].[newEDIS].[dbo].[ETFValue] where ProductType='FX' and DataDate='{lastTDate}') tCNY on T1.FCurrency2=tCNY.ProductLink "
                        + "left join "
                        + $"(select * from [10.19.1.45].[newEDIS].[dbo].[ETFValue] where ProductType='FX' and DataDate='{lastTwoDate}') yCNY on T1.FCurrency2=yCNY.ProductLink "
                        + "left join "
                        + $"(select * from [10.19.1.45].[newEDIS].[dbo].[ETFValue] where ProductType='FX' and DataDate='{lastTDate}') tJPY on T1.FCurrency3=tJPY.ProductLink "
                        + "left join "
                        + $"(select * from [10.19.1.45].[newEDIS].[dbo].[ETFValue] where ProductType='FX' and DataDate='{lastTwoDate}') yJPY on T1.FCurrency3=yJPY.ProductLink ) S1 ";
                        //+ "order by TraderNm asc, gaccountid asc, IAccountId asc, CommodityId asc ";
                        #endregion

                        etfvwDailyPL = MSSQL.ExecSqlQry(sqlStr, conn1);
                        Utility.SaveToCSV(etfvwDailyPL, $".\\vwDailyPL_{outputFileName}"+".csv", true);
                        Console.WriteLine("ETF_plAnalysis Data Output to CSV Complete...");

                        #region 寫入資料庫
#if !DEBUG
                    using (SqlConnection conn = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=newEDIS;User ID=sa;Password=dw910770"))
                    {
                        conn.Open();
                        //MSSQL.ExecSqlCmd($"DELETE FROM ETF_plAnalysis WHERE DataDate>='{lastTDate}' and DataDate<='{lastTDate} 23:59'", conn);
                        Console.WriteLine($"Inserting ETF_plAnalysis of {lastTDate}");
                        foreach (DataRow row in etfvwDailyPL.Rows)
                        {

                            string SQLcmd = $@"Insert into ETF_plAnalysis(DataDate, TraderNm,  gaccountid, Naccountid, IAccountId, CommodityId, CommodityName, Strategy, CommodityKind, "
                                + "hedgeLinkId, hedgeLinkName, CurrencyId, ContractSize, Unit, tCashDivAdj, yInvShare, tInvShare, TBuyQty, TBuyAmt, BuyAvgPrice, TSellQty, TSellAmt, SellAvgPrice, "
                                + "tNAV, tPrice, yNAV, yPrice, tSpread, ySpread, tSpreadChg, tNAVChg, tPriceChg, tFXRate, yFXRate, tFXRateChg, tFXRatePctChg, "
                                + "USDExposure_NTD, USDFXPctChg, CNYExposure_NTD, CNYFXPctChg, JPYExposure_NTD, JPYFXPctChg, SpreadChgPL, NewPosSpreadChgPL, "
                                + "ETFUSDChgPL, ETFCNYChgPL, ETFJPYChgPL, FutFXChgPL, FXChgPL, TotalSpreadChgPL, SpreadChgPL_dFX, TotalSpreadChgPL_dFX, "
                                + "NetDeltaPL, DayTradePL, totalDailyPL, tTotalCost, tDOtherIncome, tDTradePL, tDNetTradePL, TimeCategory, RecTime) Values("
                                + $"'{row[0].ToString()}','{row[1].ToString()}', '{row[2].ToString()}', '{row[3].ToString()}', '{row[4].ToString()}', '{row[5].ToString()}', '{row[6].ToString()}', '{row[7].ToString()}', '{row[8].ToString()}', '{row[9].ToString()}', "
                                + $"'{row[10].ToString()}','{row[11].ToString()}', '{row[12]}', '{row[13]}', '{row[14]}', '{row[15]}', '{row[16]}', '{row[17]}', '{row[18]}', '{row[19]}', "
                                + $"'{row[20]}','{row[21]}', '{row[22]}', '{row[23]}', '{row[24]}', '{row[25]}', '{row[26]}', '{row[27]}', '{row[28]}', '{row[29]}', "
                                + $"'{row[30]}','{row[31]}', '{row[32]}', '{row[33]}', '{row[34]}', '{row[35]}', '{row[36]}', '{row[37]}', '{row[38]}', '{row[39]}', "
                                + $"'{row[40]}','{row[41]}', '{row[42]}', '{row[43]}', '{row[44]}', '{row[45]}', '{row[46]}', '{row[47]}', '{row[48]}', '{row[49]}', "
                                + $"'{row[50]}','{row[51]}', '{row[52]}', '{row[53]}', '{row[54]}', '{row[55]}', '{row[56]}', '{row[57]}', '{row[58]}', '{row[59]}', "
                                + $"'{row[60].ToString()}')";

                                try
                                {
                                    MSSQL.ExecSqlCmd(SQLcmd, conn);
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.ToString());
                                    Console.ReadLine();
                                }


                        }

                        //Console.WriteLine(SQLcmd);

                        Console.WriteLine("Cmoney Data Insert Complete");
                    }
#endif
                        #endregion
                    }
                    catch (Exception e)
                    {
                        //Console.ReadLine();
                        MailService ms = new MailService();
                        ms.SendMail("lecheng@kgi.com", "10.60.0.37 ERROR", new string[] { "lecheng@kgi.com" }, null, null, $"{lastTDate}ETF_PL_Analysis ERROR!", e.ToString(), false, null);
                    }
                }
            }
        }
    }
}
