﻿using System;
using System.Linq;
using EDLib;
using EDLib.SQL;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using MyCSharpLib;
using System.Reflection;

namespace BrokerBuySell
{
    class Program
    {
        
        private static SqlConnection m_cnVOLDB = null, m_cnHedge = null;
        private static Dictionary<string, string> m_dicWarrants = new Dictionary<string, string>();
        private HolidayColl m_hc = new HolidayColl();

        static DataTable CM_BrokerBuySell;
        static DataTable BrokerBuySellData;
        static string lastTDate = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");
        //static string lastTDate = DateTime.Now.ToString("yyyyMMdd");
        //static string lastTDate = "20190430";
        static List<string> LastTDateList = new List<string>();

        static DataTable InitializeTables()   //For BrokerBuySellData
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("TDate", typeof(string));
            dt.Columns.Add("BrokerID", typeof(string));
            dt.Columns.Add("BrokerName", typeof(string));
            dt.Columns.Add("IssueCompany", typeof(string));
            dt.Columns.Add("BuyAmount", typeof(string));
            dt.Columns.Add("SellAmount", typeof(string));
            dt.Columns.Add("WeekLastTradeDate", typeof(string));
            dt.Columns.Add("MonthLastTradeDate", typeof(string));
            return dt;
        }
        static DataTable InitializeTables_2()  //For CM_BrokerBuySell
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("TDate", typeof(string));
            dt.Columns.Add("StockID", typeof(string));
            dt.Columns.Add("StockName", typeof(string));
            dt.Columns.Add("BrokerID", typeof(string));
            dt.Columns.Add("BrokerName", typeof(string));
            dt.Columns.Add("BuyAmount", typeof(string));
            dt.Columns.Add("SellAmount", typeof(string));
            dt.Columns.Add("IssueCompany", typeof(string));
            return dt;
        }

        /// <summary>
        /// 初始化資料庫連線
        /// </summary>
        public static void InitDatabase()
        {
            //連結到 Hedge
            //string connString = "server=10.10.1.27;uid=hedgeuser;pwd=hedgeuser;database=HEDGE";
            string connString = "server=10.101.10.5;uid=hedgeuser;pwd=hedgeuser;database=HEDGE";  //2017/4/26修改
            m_cnHedge = new SqlConnection(connString);
            m_cnHedge.Open();

            //連結到 VOL DB
            //connString = "server=10.19.1.20;uid=sa;pwd=dw910770;database=VOLDB";
            //connString = "server=10.10.1.30;uid=WarrantWeb;pwd=WarrantWeb;database=EDIS";
            //m_cnVOLDB = new SqlConnection(connString);
            //m_cnVOLDB.Open();
        }
        static void Main(string[] args)
        {
            InitDatabase();   //初始化連線
            GetWarrants();    //建立Warrant發行券商對照表
            LastTDateList.Add(lastTDate);
            foreach (string lastTDate in LastTDateList)
            {
                Console.WriteLine(lastTDate);
                Console.WriteLine("Cmoney BrokerBuySellData Query Begins...");
                try
                {
                    BrokerBuySellData = InitializeTables();
                    CM_BrokerBuySell = InitializeTables_2();
                    /// <summary>
                    /// 從 CMoney 的"券商進出個股明細" 轉出資料，並依進出與發行券商加總之後存入資料庫
                    /// </summary>
                    /// <param name="tdate"></param>
                    /// <returns></returns>
                    //string sqlStr = $"SELECT [日期] as TDate,[代號] as BrokerID,[名稱] as BrokerName,sum([買金額(千)])*1000 as BuyAmount,sum([賣金額(千)])*1000 as SellAmount FROM [券商進出個股明細] WHERE [日期]='{lastTDate}' "
                    //   + " AND LEN([股票代號]) = 6 AND ((LEFT([股票代號],2) >= '03' AND LEFT([股票代號],2) <= '08') OR (LEFT([股票代號],2) >= '70' AND LEFT([股票代號],2) <= '73')) "
                    //   + " GROUP BY [日期],[代號],[名稱] ";

                    string sqlStr_cm = $"SELECT [股票代號],[股票名稱],[代號],[名稱],[買金額(千)],[賣金額(千)] FROM [券商進出個股明細] WHERE [日期]='{lastTDate}' "
                       + " AND LEN([股票代號]) = 6 AND ((LEFT([股票代號],2) >= '03' AND LEFT([股票代號],2) <= '08') OR (LEFT([股票代號],2) >= '70' AND LEFT([股票代號],2) <= '73'))";

                    DataTable dt = MyCSharpLib.CMoney.ExecCMoneyQry(sqlStr_cm);

                    foreach (DataRow dr in dt.Rows)  //將明細資料讀到dt
                    {
                        string issueCompany = "";
                        bool res = m_dicWarrants.TryGetValue(dr["股票代號"].ToString() + "-" + dr["股票名稱"].ToString(), out issueCompany);
                        if (res == true)
                        {
                            DataRow newRow = CM_BrokerBuySell.NewRow();
                            newRow["TDate"] = DateTime.ParseExact(lastTDate, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture).ToString("yyyy/MM/dd");
                            newRow["StockID"] = dr["股票代號"].ToString();
                            newRow["StockName"] = dr["股票名稱"].ToString();
                            newRow["BrokerID"] = dr["代號"].ToString();
                            newRow["BrokerName"] = dr["名稱"].ToString();
                            newRow["BuyAmount"] = dr["買金額(千)"].ToString();
                            newRow["SellAmount"] = dr["賣金額(千)"].ToString();
                            newRow["IssueCompany"] = issueCompany.ToString();
                            CM_BrokerBuySell.Rows.Add(newRow);

                        }
                    }
                    Utility.SaveToCSV(CM_BrokerBuySell, $".\\BrokerBuySellData_{lastTDate}.csv", true);

                    #region 1. Group買賣金額 By IssueCompany, BrokerID
                    //var query = CM_BrokerBuySell.AsEnumerable().GroupBy(
                    //                    p => p.Field<String>("IssueCompany"),
                    //                    p => p.Field<String>("BrokerID")

                    //            );

                    //var query = CM_BrokerBuySell.AsEnumerable().GroupBy(
                    //            p => new
                    //            {
                    //                TDate = p.Field<string>("TDate"),
                    //                IssueCompany = p.Field<string>("IssueCompany"),
                    //                BrokerID = p.Field<string>("BrokerID"),
                    //                BrokerName = p.Field<string>("BrokerName"),

                    //            }
                    //            )
                    //            .Select(g => new
                    //            {
                    //                TDate = g.Key.TDate,
                    //                IssueCompany = g.Key.IssueCompany,
                    //                BrokerID = g.Key.BrokerID,
                    //                BrokerName = g.Key.BrokerName,
                    //                BuyAmountSum = g.Sum(x => Int32.Parse(x.Field<string>("BuyAmount"))), 
                    //                SellAmountSum = g.Sum(x => Int32.Parse(x.Field<string>("SellAmount")))
                    //            });
                    #endregion

                    #region 2. Group買賣金額 By IssueCompany, BrokerID
                    var query = from p in CM_BrokerBuySell.AsEnumerable()
                                group p by new
                                {
                                    TDate = p.Field<string>("TDate"),
                                    IssueCompany = p.Field<string>("IssueCompany"),
                                    BrokerID = p.Field<string>("BrokerID"),
                                    BrokerName = p.Field<string>("BrokerName")

                                } into g

                                select new
                                {
                                    
                                    TDate = g.Key.TDate,
                                    IssueCompany = g.Key.IssueCompany,
                                    BrokerID = g.Key.BrokerID,
                                    BrokerName = g.Key.BrokerName,
                                    BuyAmountSum = g.Sum(x => Int32.Parse(x.Field<string>("BuyAmount"))),
                                    SellAmountSum = g.Sum(x => Int32.Parse(x.Field<string>("SellAmount")))

                                };
                    #endregion

                    if (query.ToList().Count > 0)
                    {
                        foreach (var dr in query)
                        {
                            //PropertyInfo[] field = dr.GetType().GetProperties();
                            //foreach (PropertyInfo _PropertyInfo in field)
                            //{
                            //    Console.WriteLine(_PropertyInfo.Name + " : " + _PropertyInfo.GetValue(dr, null));
                            //}
                            Console.WriteLine(dr.TDate + ", " + dr.IssueCompany + ", " + dr.BrokerID + ", " + dr.BrokerName + ", " + dr.BuyAmountSum + ", " + dr.SellAmountSum);

                            DataRow newRow = BrokerBuySellData.NewRow();
                            newRow["TDate"] = dr.TDate;
                            newRow["BrokerID"] = dr.BrokerID;
                            newRow["BrokerName"] = dr.BrokerName;
                            newRow["BuyAmount"] = dr.BuyAmountSum;
                            newRow["SellAmount"] = dr.SellAmountSum;
                            newRow["IssueCompany"] = dr.IssueCompany;
                            //newRow["WeekLastTradeDate"] = dr["StockID"];
                            //newRow["MonthLastTradeDate"] = dr["StockName"];
                            BrokerBuySellData.Rows.Add(newRow);
                        }
                    }
                    
                    
                    Utility.SaveToCSV(BrokerBuySellData, $".\\BrokerBuySellData_{lastTDate}.csv", true);


                }
                catch (Exception e)
                {
                    e.ToString();
                }

            }

        }

        /// <summary>
        /// 取得 Warrants 資料
        /// </summary>
        public static void GetWarrants()
        {
            try
            {
                string strSQL = "SELECT wid + '-' + wname AS wid, ISSUECOMNAME, maturitydate FROM dbo.WARRANTS WHERE (maturitydate >= '2016/01/01') ORDER BY issuedate DESC";
                DataTable dt = MyCSharpLib.MSSQL.QuerySQL(m_cnHedge, strSQL); //DBUtil.QuerySQL(this.m_cnHedge, strSQL);
                
                foreach (DataRow dr in dt.Rows)
                {
                    string tmp = "";
                    if (m_dicWarrants.TryGetValue(dr["Wid"].ToString(), out tmp) == false)
                        m_dicWarrants.Add(dr["Wid"].ToString(), dr["ISSUECOMNAME"].ToString());
                }
            }
            catch (Exception e_wrr)
            {
                e_wrr.ToString();
            }
        }

        /// <summary>
        /// 取得當週最後一個交易日
        /// </summary>
        /// <param name="tdate"></param>
        /// <returns></returns>
        private string GetWeekLastTradeDate(DateTime tdate)
        {
            int addDays = 0;

            switch (tdate.DayOfWeek)
            {
                case DayOfWeek.Monday:
                    addDays = 5;
                    break;

                case DayOfWeek.Tuesday:
                    addDays = 4;
                    break;

                case DayOfWeek.Wednesday:
                    addDays = 3;
                    break;

                case DayOfWeek.Thursday:
                    addDays = 2;
                    break;

                case DayOfWeek.Friday:
                    addDays = 1;
                    break;

                case DayOfWeek.Saturday:
                    addDays = 0;
                    break;

                case DayOfWeek.Sunday:
                    addDays = -1;
                    break;
            }

            DateTime res = tdate.AddDays(addDays);
            while (this.m_hc.IsWorkDate(res) == false)
                res = res.AddDays(-1);

            return res.ToString("yyyy/MM/dd");
        }
        /// <summary>
        /// 取得當月最後一個交易日
        /// </summary>
        /// <param name="tdate"></param>
        private string GetMonthLastTradeDate(DateTime tdate)
        {
            DateTime res = MyCSharpLib.DateTimeUtility.GetMonthLastDate(tdate);
            while (this.m_hc.IsWorkDate(res) == false)
                res = res.AddDays(-1);

            return res.ToString("yyyy/MM/dd");
        }




    }
}
